package com.example.week12a

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
